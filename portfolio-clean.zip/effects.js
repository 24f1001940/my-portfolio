/**
 * EFFECTS.JS — Interactive Three.js 3D WebGL Universe & UI Physics Engine
 * Automatically binds to portfolio cards, hero sections, buttons, and scroll events.
 */

(function () {
  'use strict';

  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ==========================================================================
     1. SCROLL PROGRESS BAR
     ========================================================================== */
  function initScrollProgress() {
    let bar = document.getElementById('fx-scroll-progress');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'fx-scroll-progress';
      document.body.prepend(bar);
    }

    window.addEventListener('scroll', () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      bar.style.width = `${progress}%`;
    }, { passive: true });
  }

  /* ==========================================================================
     2. CUSTOM DUAL-RING INTERACTIVE CURSOR
     ========================================================================== */
  function initCustomCursor() {
    if (isTouchDevice || prefersReducedMotion) return;

    const dot = document.createElement('div');
    dot.className = 'fx-cursor-dot';
    const ring = document.createElement('div');
    ring.className = 'fx-cursor-ring';
    document.body.appendChild(dot);
    document.body.appendChild(ring);

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let ringX = mouseX;
    let ringY = mouseY;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      dot.style.left = `${mouseX}px`;
      dot.style.top = `${mouseY}px`;
    }, { passive: true });

    function animateCursor() {
      ringX += (mouseX - ringX) * 0.18;
      ringY += (mouseY - ringY) * 0.18;
      ring.style.left = `${ringX}px`;
      ring.style.top = `${ringY}px`;
      requestAnimationFrame(animateCursor);
    }
    animateCursor();

    const interactiveSelectors = 'a, button, .btn, input, textarea, select, [role="button"], .project-card, .card, .course-card, .cert-card';
    document.addEventListener('mouseover', (e) => {
      if (e.target.closest(interactiveSelectors)) {
        ring.classList.add('fx-cursor-hover');
      }
    });
    document.addEventListener('mouseout', (e) => {
      if (e.target.closest(interactiveSelectors)) {
        ring.classList.remove('fx-cursor-hover');
      }
    });
  }

  /* ==========================================================================
     3. 3D PERSPECTIVE TILT & SPECULAR GLARE FOR CARDS
     ========================================================================== */
  function init3DTiltCards() {
    if (isTouchDevice || prefersReducedMotion) return;

    const cardSelectors = [
      '.project-card',
      '.card',
      '.skill-card',
      '.cert-card',
      '.certification-card',
      '.course-card',
      '.experience-card',
      '.timeline-content',
      '.bento-item',
      '.glass-card',
      '[data-tilt]'
    ].join(', ');

    const attachTilt = (card) => {
      if (card.dataset.fxTiltBound) return;
      card.dataset.fxTiltBound = 'true';
      card.classList.add('fx-tilt-card');

      let glare = card.querySelector('.fx-glare');
      if (!glare) {
        glare = document.createElement('div');
        glare.className = 'fx-glare';
        card.appendChild(glare);
      }

      const maxTilt = parseFloat(card.dataset.maxTilt) || 10;

      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * -maxTilt;
        const rotateY = ((x - centerX) / centerX) * maxTilt;

        card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`;

        const percentX = (x / rect.width) * 100;
        const percentY = (y / rect.height) * 100;
        glare.style.background = `radial-gradient(circle at ${percentX}% ${percentY}%, rgba(255, 255, 255, 0.25) 0%, rgba(255, 255, 255, 0.04) 40%, transparent 70%)`;
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
      });
    };

    const scanCards = () => {
      document.querySelectorAll(cardSelectors).forEach(attachTilt);
    };

    scanCards();
    // Re-scan when dynamic JSON content (courses.json / saqib_certifications.json) loads
    const observer = new MutationObserver(scanCards);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  /* ==========================================================================
     4. MAGNETIC BUTTON PHYSICS
     ========================================================================== */
  function initMagneticButtons() {
    if (isTouchDevice || prefersReducedMotion) return;

    const btnSelectors = '.btn, .cta-btn, .hero-btn, .social-link, .nav-cta, [data-magnetic]';
    document.querySelectorAll(btnSelectors).forEach((btn) => {
      btn.classList.add('fx-magnetic');
      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        btn.style.transform = `translate(${x * 0.28}px, ${y * 0.28}px)`;
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.transform = 'translate(0px, 0px)';
      });
    });
  }

  /* ==========================================================================
     5. 3D SCROLL REVEAL OBSERVER
     ========================================================================== */
  function initScrollReveal3D() {
    if (prefersReducedMotion) return;

    const revealSelectors = 'section > .container, .section-title, .project-card, .skill-category, .cert-card, .course-card, .timeline-item';
    const elements = document.querySelectorAll(revealSelectors);

    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('fx-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    elements.forEach((el, index) => {
      el.classList.add('fx-reveal');
      el.style.transitionDelay = `${(index % 4) * 70}ms`;
      io.observe(el);
    });
  }

  /* ==========================================================================
     6. THREE.JS INTERACTIVE 3D WEBGL SCENE
     ========================================================================== */
  function loadThreeJSAndStart() {
    if (prefersReducedMotion) return;

    if (window.THREE) {
      build3DScene();
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    script.async = true;
    script.onload = build3DScene;
    document.head.appendChild(script);
  }

  function build3DScene() {
    const THREE = window.THREE;
    if (!THREE) return;

    let canvas = document.getElementById('webgl-3d-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'webgl-3d-canvas';
      document.body.prepend(canvas);
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 32;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // A. Interactive Particle Starfield
    const particleCount = isTouchDevice ? 600 : 1400;
    const posArray = new Float32Array(particleCount * 3);
    const colorArray = new Float32Array(particleCount * 3);

    const palette = [
      new THREE.Color('#6366f1'), // Indigo
      new THREE.Color('#06b6d4'), // Cyan
      new THREE.Color('#a855f7'), // Purple
      new THREE.Color('#38bdf8')  // Sky
    ];

    for (let i = 0; i < particleCount; i++) {
      posArray[i * 3] = (Math.random() - 0.5) * 90;
      posArray[i * 3 + 1] = (Math.random() - 0.5) * 90;
      posArray[i * 3 + 2] = (Math.random() - 0.5) * 70;

      const c = palette[Math.floor(Math.random() * palette.length)];
      colorArray[i * 3] = c.r;
      colorArray[i * 3 + 1] = c.g;
      colorArray[i * 3 + 2] = c.b;
    }

    const particlesGeo = new THREE.BufferGeometry();
    particlesGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    particlesGeo.setAttribute('color', new THREE.BufferAttribute(colorArray, 3));

    const particlesMat = new THREE.PointsMaterial({
      size: 0.22,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending
    });

    const particleMesh = new THREE.Points(particlesGeo, particlesMat);
    scene.add(particleMesh);

    // B. 3D Wireframe Cyber-Core (Icosahedron + Outer Torus Ring)
    const coreGroup = new THREE.Group();
    scene.add(coreGroup);

    const icoGeo = new THREE.IcosahedronGeometry(7.5, 1);
    const icoMat = new THREE.MeshBasicMaterial({
      color: 0x6366f1,
      wireframe: true,
      transparent: true,
      opacity: 0.16
    });
    const icoMesh = new THREE.Mesh(icoGeo, icoMat);
    coreGroup.add(icoMesh);

    const torusGeo = new THREE.TorusGeometry(11.5, 0.08, 16, 100);
    const torusMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.28
    });
    const torusMesh = new THREE.Mesh(torusGeo, torusMat);
    torusMesh.rotation.x = Math.PI / 3;
    coreGroup.add(torusMesh);

    const octaGeo = new THREE.OctahedronGeometry(4.2, 0);
    const octaMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      wireframe: true,
      transparent: true,
      opacity: 0.22
    });
    const octaMesh = new THREE.Mesh(octaGeo, octaMat);
    coreGroup.add(octaMesh);

    // Position the 3D core slightly to the right on desktop for Hero balance
    coreGroup.position.x = window.innerWidth > 992 ? 12 : 0;

    // Mouse & Scroll Interaction Tracking
    let targetX = 0;
    let targetY = 0;
    let scrollY = window.scrollY;

    window.addEventListener('mousemove', (e) => {
      targetX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetY = (e.clientY / window.innerHeight - 0.5) * 2;
    }, { passive: true });

    window.addEventListener('scroll', () => {
      scrollY = window.scrollY;
    }, { passive: true });

    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      coreGroup.position.x = window.innerWidth > 992 ? 12 : 0;
    });

    // Animation Loop
    const clock = new THREE.Clock();

    function animate() {
      requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Rotate geometric core
      icoMesh.rotation.y = elapsedTime * 0.18;
      icoMesh.rotation.x = elapsedTime * 0.1;
      torusMesh.rotation.z = -elapsedTime * 0.25;
      octaMesh.rotation.y = -elapsedTime * 0.35;
      octaMesh.rotation.z = elapsedTime * 0.2;

      // Subtle floating wave
      coreGroup.position.y = Math.sin(elapsedTime * 0.8) * 1.2 - scrollY * 0.008;

      // Mouse parallax easing
      coreGroup.rotation.y += (targetX * 0.6 - coreGroup.rotation.y) * 0.05;
      coreGroup.rotation.x += (targetY * 0.6 - coreGroup.rotation.x) * 0.05;

      particleMesh.rotation.y = elapsedTime * 0.03 + targetX * 0.12;
      particleMesh.rotation.x = -scrollY * 0.0003 + targetY * 0.12;

      renderer.render(scene, camera);
    }

    animate();
  }

  /* ==========================================================================
     INITIALIZE ALL MODULES ON DOM READY
     ========================================================================== */
  function initAllEffects() {
    initScrollProgress();
    initCustomCursor();
    init3DTiltCards();
    initMagneticButtons();
    initScrollReveal3D();
    loadThreeJSAndStart();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAllEffects);
  } else {
    initAllEffects();
  }
})();